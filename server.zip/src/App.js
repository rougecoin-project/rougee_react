import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LoginPage from './components/LoginPage';
import CreateAccount from './components/CreateAccount';
import ProfileUpdate from './components/ProfileUpdate';
import Feed from './components/Feed';
import logo from './assets/images/logo.png';
import HamburgerMenu from './components/HamburgerMenu'; // Import the HamburgerMenu component
import ExplorePage from './components/ExplorePage';
import BottomNavbar from './components/BottomNavbar'; // Import the BottomNavbar component

function App() {
  return (
    <Router>
      <div className="App">
        <img src={logo} alt="RouGee Logo" className="logo" />
        <HamburgerMenu /> {/* Place the HamburgerMenu component here */}
        <Routes>
          <Route path="/" element={<LoginPage />} />
          <Route path="/loginpage" element={<LoginPage />} />
          <Route path="/createaccount" element={<CreateAccount />} />
          <Route path="/profileupdate" element={<ProfileUpdate />} />
          <Route path="/feed" element={<Feed />} />
          <Route path="/explore" element={<ExplorePage />} /> {/* New Route for ExplorePage */}
        </Routes>
        <BottomNavbar /> {/* Place the BottomNavbar component here */}
      </div>
    </Router>
  );
}

export default App;
