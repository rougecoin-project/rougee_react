import FormData from 'form-data';

const rougeeApiBaseUrl = "https://rougee.io/api/";

const endpoints = {
    createAccount: "create-account",
    getUserData: "user-data",
    profileUpdate: "update-user-data",
    loginPage: "auth",
    promotedPost: "get-promoted-post"
    // Add more endpoints as needed
};

// ... other imports and functions ...

function getPostData(post_id, fetchKeys) {
    const endpoint = "http://your-site.com/api/get-post-data";
    const accessToken = "YOUR_ACCESS_TOKEN"; // Replace with the actual token or fetch dynamically
  
    return fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        post_id: post_id,
        fetch: fetchKeys,
        access_token: accessToken,
      }),
    })
    .then(response => response.json())
    .then(data => {
      if (data.api_status === 200) {
        return data; // This will contain the keys sent in fetch
      } else {
        throw new Error("Error fetching post data.");
      }
    });
  }
  
  // ... other exports ...

const SERVER_KEY = "55f12885e31123142b34db242d072af8";  // Define the server key as a constant


async function makeApiRequest(endpoint, requestData, onTokenInvalid) {
    try {
        const accessToken = localStorage.getItem('access_token'); // Retrieve the access token from local storage
        const apiUrl = `${rougeeApiBaseUrl}${endpoint}?access_token=${accessToken}`;

        const formData = new FormData();

        formData.append('server_key', SERVER_KEY);  // Always append the server key

        // Append other form fields from requestData
        for (const key in requestData) {
            if (Object.hasOwnProperty.call(requestData, key)) {
                formData.append(key, requestData[key]);
            }
        }

        const response = await fetch(apiUrl, {
            method: 'POST',
            body: formData,
        });

        const data = await response.json();

        if (data.api_status === 401) {
            localStorage.removeItem('access_token');  // Remove the invalid token
            onTokenInvalid && onTokenInvalid();  // Callback to handle token invalidation
            throw new Error('Token is invalid or expired.');
        }

        if (!response.ok) {
            throw new Error(`API request failed with status ${response.status}`);
        }

        return data;

    } catch (error) {
        console.error("API request error:", error);
        throw error;
    }
}


export { makeApiRequest, endpoints, rougeeApiBaseUrl, getPostData };  // Exporting the base URL as well
