// FeedContext.js
import { createContext } from 'react';
const FeedContext = createContext();
export default FeedContext;
