import React, { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { makeApiRequest, endpoints } from "../api";
import BottomNavbar from "../components/BottomNavbar";
import PostPlaceholder from './PostPlaceholder'; // Import the PostPlaceholder component

function linkify(inputText) {
  const urlRegex = /(((https?:\/\/)|(www\.))[^\s]+)/g;
  return inputText.replace(urlRegex, (url) => {
    let hyperlink = url;
    if (!url.match(/^http?:\/\//i)) {
      hyperlink = "http://" + url;
    }
    return (
      '<a href="' +
      hyperlink +
      '" target="_blank" rel="noopener noreferrer">' +
      url +
      "</a>"
    );
  });
}

function handleHashtags(inputText) {
  const hashtagRegex = /#([a-zA-Z0-9_]+)/g;
  return inputText.replace(hashtagRegex, (match, tag) => {
    return `{{HASHTAG:${tag}}}`;
  });
}

function replaceHashtagsWithLinks(inputText) {
  const placeholderRegex = /{{HASHTAG:([a-zA-Z0-9_]+)}}/g;
  return inputText.replace(placeholderRegex, (match, tag) => {
    return `<a href="https://rougee.io/hashtag/${tag}">#${tag}</a>`;
  });
}

function renderVideoContent(post) {
  if (post.postYoutube) {
    return (
      <iframe
        title="YouTube Video"
        width="560"
        height="315"
        src={`https://www.youtube.com/embed/${post.postYoutube}`}
        frameBorder="0"
        allowFullScreen
      ></iframe>
    );
  } else if (post.postVimeo) {
    return (
      <iframe
        title="Vimeo Video"
        src={`https://player.vimeo.com/video/${post.postVimeo}`}
        width="560"
        height="315"
        frameBorder="0"
        allowFullScreen
      ></iframe>
    );
  }

  if (
    post.postFile_full &&
    post.postFile_full.includes("https://rougee.io/upload/videos")
  ) {
    return (
      <video width="560" height="315" controls>
        <source src={post.postFile_full} type="video/mp4" />
        Your browser does not support the video tag.
      </video>
    );
  }

  if (post.postLinkImage) {
    return <img src={post.postLinkImage} alt="Post Link" />;
  }

  return null;
}

function Feed(props) {
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [promotedPost, setPromotedPost] = useState(null);
  const [refreshCounter, setRefreshCounter] = useState(0); // Add this line

  const navigate = useNavigate();
  const [isExpanded, setIsExpanded] = useState(false);
  
  const refreshFeed = useCallback(() => { // Add this function
    setRefreshCounter((prevCount) => prevCount + 1);
  }, []);

  useEffect(() => {
    // Define fetchFeedData inside the useEffect
    const fetchFeedData = () => {
      setLoading(true);
  
      makeApiRequest(endpoints.promotedPost, {}, () => {
        navigate("/loginpage");
      })
        .then((data) => {
          if (data.api_status === 200) {
            setPromotedPost(data.data);
            setLoading(false);
          } else {
            setError("Error fetching promoted post.");
            setLoading(false);
          }
        })
        .catch((error) => {
          console.error("Error fetching promoted post:", error);
          setError("Network or server error.");
          setLoading(false);
        });
    };
  
    fetchFeedData(); // Call fetchFeedData here
  
    // Add navigate to the dependency array
  }, [navigate, refreshCounter]); // Add refreshCounter to dependency array

  if (loading) {
    return (
      <div>
        <PostPlaceholder />
        <PostPlaceholder />
        <PostPlaceholder />
        <PostPlaceholder />
        <PostPlaceholder />
        {/* Render as many PostPlaceholders as you want */}
      </div>
    );
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  let postElement = null;

  if (promotedPost) {
    const processedText = replaceHashtagsWithLinks(
      linkify(
        handleHashtags(
          isExpanded
            ? promotedPost.postText
            : `${promotedPost.postText.substring(0, 100)}...`
        )
      )
    );
    const finalText = processedText.replace(/PLACEHOLDER/g, 'https://');

    postElement = (
      <div className="post-box">
        <div className="post-header">
          <img className="avatar" src={promotedPost.publisher.avatar} alt="User Avatar" />
          <h3>{promotedPost.publisher.username}</h3>
        </div>
        <div className="post-content">
          <h2>Promoted Post</h2>
          <p dangerouslySetInnerHTML={{ __html: finalText }}></p>
          <span onClick={() => setIsExpanded(!isExpanded)} style={{ color: "blue", cursor: "pointer" }}>
            {isExpanded ? " See Less" : " See More"}
          </span>
          {renderVideoContent(promotedPost) || (
            <img src={promotedPost.postFile_full} alt="Promoted" />
          )}
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="feed-container">
        {postElement}
      </div>
      <BottomNavbar onHomeClick={refreshFeed} /> {/* Pass the refreshFeed function as a prop */}
    </div>
  );
}

export default Feed;
